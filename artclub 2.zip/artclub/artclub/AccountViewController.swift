//
//  AccountViewController.swift
//  artclub
//
//  Created by Костя Дегтярев on 19.10.2021.
//

import UIKit

class AccountViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }

    @IBAction func GoToMenu(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}

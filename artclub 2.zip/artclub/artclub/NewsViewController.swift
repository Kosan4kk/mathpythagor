//
//  NewsViewController.swift
//  artclub
//
//  Created by Костя Дегтярев on 19.10.2021.
//

import UIKit

class NewsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    
    @IBAction func goToMain(_ sender: Any) {
        performSegue(withIdentifier: "goToMain", sender: nil)
    }
    
    @IBAction func goToRegister(_ sender: Any) {
        performSegue(withIdentifier: "goToRegister", sender: nil)
    }
    @IBAction func goToMessage(_ sender: Any) {
        performSegue(withIdentifier: "goToMessage", sender: nil)
    }
}

//
//  RegisterViewController.swift
//  artclub
//
//  Created by Костя Дегтярев on 19.10.2021.
//

import UIKit

class RegisterViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    @IBAction func goToMain(_ sender: Any) {
        performSegue(withIdentifier: "goToMain", sender: nil)
    }
    
    @IBAction func goToNews(_ sender: Any) {
        performSegue(withIdentifier: "goToNews", sender: nil)
    }
    

    @IBAction func goToMessage(_ sender: Any) {
        performSegue(withIdentifier: "goToMessage", sender: nil)
    }
}

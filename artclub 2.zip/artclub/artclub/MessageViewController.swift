//
//  MessageViewController.swift
//  artclub
//
//  Created by Костя Дегтярев on 19.10.2021.
//

import UIKit

class MessageViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func goToMain(_ sender: Any) {
        performSegue(withIdentifier: "goToMain", sender: nil)
    }
    @IBAction func goToNews(_ sender: Any) {
        performSegue(withIdentifier: "goToNews", sender: nil)
    }
    @IBAction func goToRegister(_ sender: Any) {
        performSegue(withIdentifier: "goToRegister", sender: nil)
    }
}

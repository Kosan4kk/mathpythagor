//
//  EventViewController.swift
//  artclub
//
//  Created by Костя Дегтярев on 19.10.2021.
//

import UIKit

class EventViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }

    @IBAction func GoToMain(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}

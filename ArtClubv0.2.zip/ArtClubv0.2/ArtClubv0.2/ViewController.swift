//
//  ViewController.swift
//  ArtClubv0.2
//
//  Created by Костя Дегтярев on 31.10.2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

